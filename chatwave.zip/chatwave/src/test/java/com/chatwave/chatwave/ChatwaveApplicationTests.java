package com.chatwave.chatwave;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatwaveApplicationTests {

	@Test
	void contextLoads() {
	}

}
