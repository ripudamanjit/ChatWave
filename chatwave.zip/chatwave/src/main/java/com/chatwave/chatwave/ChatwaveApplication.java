package com.chatwave.chatwave;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChatwaveApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChatwaveApplication.class, args);
	}

}
